<?php
$alphabet = "0123456789abcdefghijklmnopqrstuvwxyz";
$allowed_symbols = "23456789abcdeghkmnpqsuvxyz"; 
$fontsdir = 'fonts';	
$length = 5; 
$width = 90;
$height = 50;
$fluctuation_amplitude = 10;
$no_spaces = true;
$show_credits = false; 
$credits = 'abc'; 
$foreground_color = array(mt_rand(0,100), mt_rand(0,100), mt_rand(0,100));
$background_color = array(mt_rand(200,255), mt_rand(200,255), mt_rand(200,255));
$jpeg_quality = 100;
?>